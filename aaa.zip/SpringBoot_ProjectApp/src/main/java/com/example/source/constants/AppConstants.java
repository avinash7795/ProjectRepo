package com.example.source.constants;

public interface AppConstants {
  public static final String REG_SUCCESS="regSuccess";
  public static final String SUCCESS_MSG="SuccessMsg";
  public static final String FAILURE_MSG="failureMsg";
  public static final String USER_REG_VIEW="userRegForm";
  public static final String USER_MODEL_OBJ="user";
  public static final String DISPLAY_USER_VIEW="displayUsers";
  public static final String USERS_MODEL_OBJ="users";
  public static final String ACTIVE="ACTIVE";
  public static final String DELETED="DELETED";
}
