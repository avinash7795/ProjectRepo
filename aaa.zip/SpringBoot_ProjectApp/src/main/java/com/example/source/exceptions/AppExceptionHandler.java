package com.example.source.exceptions;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@Controller
@ControllerAdvice
public class AppExceptionHandler {
 public AppExceptionHandler() {
	System.out.println("app exception handler executed");
}
    
    @ExceptionHandler(value=NullPointerException.class)
	public String handleException(Model model) {
		model.addAttribute("errorMsg","sorry,something went wrong try some later");
		return "errorPage";
	}
   
    @ExceptionHandler(value=UserNotFoundException.class)
	public String handleExceptionByMethod(Model model) {
    	model.addAttribute("errorMsg","sorry,something went wrong try some later");
		return "errorPage";
	}
}
