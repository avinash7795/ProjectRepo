package com.example.source.entity;

import javax.persistence.Column;
import javax.persistence.Entity;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import lombok.Data;

/**
 * @author avinash
 * this class is used to map to database table
 *
 */
@Data
@Entity
@Table(name = "USER_ENTITY")
public class UserEntity {
	@Id
	@SequenceGenerator(name = "COL_GEN", sequenceName = "COL_SQE")
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "COL_GEN")
	@Column(name = "USER_ID")
	private Integer userId;
	@Column(name = "USERNAME")
	private String username;
	@Column(name = "PASSWORD")
	private String password;

	@Column(name = "EMAIL")
	private String email;
	@Column(name = "PHNO")
	private Long phno;
	@Column(name = "COUNTRY")
	private String country;
	
	@Column(name="STATE")
	//@Enumerated(EnumType.STRING)
	private String state;	
}
