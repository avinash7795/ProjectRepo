package com.example.source.restcontroller;

import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.source.entity.UserEntity;
import com.example.source.pojo.User;
import com.example.source.repo.UserMasterRepo;

@RestController
public class CustomerRestController {
	@Autowired
	private UserMasterRepo userMasterRepo;
  
	@GetMapping(value="/get",produces= {"application/json","application/xml"})
		public User getUserById(@RequestParam("uid") Integer uid) {
		System.out.println("get user by id method called");
		Optional<UserEntity> opt=userMasterRepo.findById(uid);
		User user=new User();
		
		UserEntity entity=opt.get();
		
		BeanUtils.copyProperties(entity, user);
		return user;
	}
}
