package com.example.source.enums;

public enum UserState {
 INACTIVE,ACTIVE,DELETED;
}
