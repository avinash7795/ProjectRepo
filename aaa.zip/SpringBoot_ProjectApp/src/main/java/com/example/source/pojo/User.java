package com.example.source.pojo;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import lombok.Data;

@Data
@XmlRootElement

@XmlAccessorType(XmlAccessType.FIELD)
public class User {
	@XmlElement
	private Integer userId;
	@XmlElement
	private String username;
	@XmlElement
	private String password;
	@XmlElement
	private String email;
	@XmlElement
	private long phno;
	@XmlElement
	private String country;
	@XmlElement
	private String state;

	@Override
	public String toString() {
		return "User [username=" + username + ", password=" + password + ", email=" + email + ", phno=" + phno
				+ ", country=" + country + "]";
	}

}
