package com.example.source.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.source.constants.AppConstants;
import com.example.source.entity.UserEntity;
import com.example.source.exceptions.UserNotFoundException;
import com.example.source.pojo.User;
import com.example.source.repo.UserMasterRepo;

@Controller
public class UserController {
	@Autowired
	private AppProperties appProps;

	@Autowired
	private UserMasterRepo userEntityRepo;

	public UserController() {
		System.out.println("user controller::constructor");
	}

	/**
	 * this method is used to display form in ui
	 * 
	 * @param model
	 * @param user
	 * @return
	 */
	@RequestMapping(value = "/regForm")
	public String loadRegForm(Model model) {

		User userObj = new User();

		model.addAttribute(AppConstants.USER_MODEL_OBJ, userObj);
		loadFormData(model);
		return AppConstants.USER_REG_VIEW;
	}

	/**
	 * this method is used to handle user creation in page
	 * 
	 * @param user
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/regForm", method = RequestMethod.POST)
	public String formSubmit(@ModelAttribute(AppConstants.USER_MODEL_OBJ) User user, Model model,
			RedirectAttributes attributes) {
		String msg = appProps.getMessages().get(AppConstants.REG_SUCCESS);
		System.out.println("usercreate method called");
		UserEntity entity = new UserEntity();
		entity.setState(AppConstants.ACTIVE);
		BeanUtils.copyProperties(user, entity);
		UserEntity saveRepo = userEntityRepo.save(entity);

		System.out.println(user.toString());
		// model.addAttribute("succMsg", "Registration successful");
		// logic to store in db

		if (saveRepo.getUserId() != null) {
			// model.addAttribute(AppConstants.SUCCESS_MSG,msg);
			attributes.addFlashAttribute(AppConstants.SUCCESS_MSG, msg);
		} else {
			// error message
			throw new UserNotFoundException("sorry something went wrong..! please try again later");
		}
		return "redirect:/userCreationSuccess";
		// return AppConstants.USER_REG_VIEW;
	}

	/**
	 * this method is used to display success msg post registration
	 * 
	 * @param model
	 */
	@RequestMapping(value = "/userCreationSuccess")
	public String userCreationSuccess(Model model) {

		User userObj = new User();

		model.addAttribute(AppConstants.USER_MODEL_OBJ, userObj);

		return AppConstants.USER_REG_VIEW;
	}

	/**
	 * This function is used to retrieve all the users in the database using pagination
	 * 
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/viewUsers")
	public String viewUsers(Model model, @RequestParam("pn") Integer currentPageNo) {
		int count = 0;
		if (currentPageNo != 0) {
			System.out.println("view users method called");
			Integer pageSize = 3;
			PageRequest page = PageRequest.of(currentPageNo - 1, pageSize);
			Page<UserEntity> userPage = userEntityRepo.findAll(page);

			List<UserEntity> list = userPage.getContent();
			int totalPages = userPage.getTotalPages();
			model.addAttribute("tp", totalPages);

			for (UserEntity entity : list) {
				if (entity.getState().equalsIgnoreCase(AppConstants.DELETED)) {
					count++;
				}
			}
			if (count == 3) {
				currentPageNo++;
				return "redirect:viewUsers?pn=" + currentPageNo;
			} else {
				List<User> usersList = new ArrayList<User>();
				for (UserEntity entity2 : list) {
					User user = new User();
					if (entity2.getState().equalsIgnoreCase(AppConstants.DELETED)) {
						continue;
					}

					else {
						BeanUtils.copyProperties(entity2, user);
						usersList.add(user);
					}
					model.addAttribute(AppConstants.USERS_MODEL_OBJ, usersList);

					model.addAttribute("cp", currentPageNo);
				}
			}
			// Iterable<UserEntity> usersEntities=userEntityRepo.findAll();

		} else {

			// error message
			throw new UserNotFoundException("sorry something went wrong..! please try again later");

		}
		return AppConstants.DISPLAY_USER_VIEW;
	}

	/**
	 * This function is used to delete particular user by id
	 * 
	 * @param userId
	 * @return
	 */
	@RequestMapping(value = "deleteUser")
	public String deleteUserById(@RequestParam("uid") Integer userId) {
		if (userId != 0) {
			System.out.println("delete user by id method called");
			Optional<UserEntity> eid = userEntityRepo.findById(userId);
			UserEntity ent = eid.get();
			// ent.deleteUser();
			ent.setState(AppConstants.DELETED);
			userEntityRepo.save(ent);
		} else {
			// error message
			throw new UserNotFoundException("sorry something went wrong..! please try again later");
		}
		return "redirect:/viewUsers?pn=1";
	}

	/**
	 * This method is used to edit the user details as required
	 * 
	 * @param model
	 * @param userId
	 * @return
	 */
	@RequestMapping(value = "/editUser")
	public String editUser(Model model, @RequestParam("uid") Integer userId) {
		if (userId != 0) {
			System.out.println("edit users method called");
			Optional<UserEntity> optEntity = userEntityRepo.findById(userId);
			if (optEntity.isPresent()) {
				UserEntity entity = optEntity.get();
				User user = new User();
				BeanUtils.copyProperties(entity, user);
				model.addAttribute("user", user);
				loadFormData(model);

			}
		} else {
			// error message
			throw new UserNotFoundException("sorry something went wrong..! please try again later");
		}
		return "editUser";

	}

	/**
	 * This method is used to return all the email ids from database in response
	 * type
	 * 
	 * @return json
	 */
	@RequestMapping(value = "/getEmails")
	public @ResponseBody List<String> findAllUsersEmails() {

		return userEntityRepo.findAllEmails();
	}

	/**
	 * This method is used to return particular email id by given id in string
	 * format
	 * 
	 * @param uid
	 * @return string
	 */
	@RequestMapping(value = "/getEmailById")
	public String findEmailById(@RequestParam("uid") Integer uid, Model model) {
		if (uid != 0) {
			String msg = userEntityRepo.findEmailById(uid);
			model.addAttribute("msg", msg);

			return "display";
		} else {
			// error message
			throw new UserNotFoundException("sorry something went wrong..! please try again later");
		}
	}

	/**
	 * This method is used to update the userdetails in the database
	 * 
	 * @param user
	 * @param model
	 * @param uid
	 * @return
	 */
	@RequestMapping(value = "/updateUser", method = RequestMethod.POST)
	public String updateUser(@ModelAttribute("user") User user, Model model, @RequestParam("uid") Integer uid) {
		if (uid != 0) {
			System.out.println("update user method called");

			user.setUserId(uid);
			UserEntity entity = new UserEntity();
			BeanUtils.copyProperties(user, entity);
			entity.setState(AppConstants.ACTIVE);
			UserEntity savedEntity = userEntityRepo.save(entity);
			if (savedEntity.getUserId() != null) {
				model.addAttribute("succMsg", "Updated Successfully");
			}

			loadFormData(model);
		} else {
			// error message
			throw new UserNotFoundException("sorry something went wrong..! please try again later");
		}
		return "editUser";
	}

	/*
	 * @RequestMapping(value="/getEntitiesByCountry") public @ResponseBody String
	 * findEntitiesByCountry(@RequestParam("country") String country){
	 * System.out.println("find by country called"); return
	 * userEntityRepo.findByCountryContains(country); }
	 */

	/**
	 * This method is used to load country dropdowns in form automatically
	 * 
	 * @param model
	 */
	public static void loadFormData(Model model) {
		;
		List<String> countries = new ArrayList<String>();
		countries.add("India");
		countries.add("United States");
		countries.add("Brazil");
		model.addAttribute("countryList", countries);
	}
}
