package com.example.source.repo;

import java.io.Serializable;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.example.source.entity.UserEntity;

@Repository
public interface UserMasterRepo extends JpaRepository<UserEntity,Serializable>{
     @Query(value="select email from UserEntity")
	public List<String> findAllEmails();
     @Query(value="select email from UserEntity where userId=:uid")
     public String findEmailById(Integer uid);
   
}
