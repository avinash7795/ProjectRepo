package com.nit.avi.test;

import static org.assertj.core.api.Assertions.assertThat;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import java.util.Date;

import java.util.Optional;

import org.junit.Test;
import org.junit.runner.RunWith;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;
import org.springframework.test.context.junit4.SpringRunner;

import com.nit.avi.constants.AppConstants;
import com.nit.avi.entity.AddressEntity;
import com.nit.avi.entity.OwnerEntity;
import com.nit.avi.entity.VehicleEntity;
import com.nit.avi.entity.VehicleRegEntity;
import com.nit.avi.repo.UserMasterRepo;
import com.nit.avi.repo.UserMasterRepo2;
import com.nit.avi.repo.UserMasterRepo3;
import com.nit.avi.repo.UserMasterRepo4;
@RunWith(SpringRunner.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace = Replace.NONE)
public class OwnerDetailsTest {
	
	  @Autowired 
	  private TestEntityManager entityManager;
	 
		
		@Autowired
		private UserMasterRepo userEntityRepo;
		
		@Autowired
		private UserMasterRepo2 userEntityRepo2;

		@Autowired
		private UserMasterRepo3 userEntityRepo3;

		@Autowired
		private UserMasterRepo4 userEntityRepo4;
	
	@Test
	public void testSaveOwnerDetails() throws ParseException {
		String strDate="12/06/1995";
		Date date1 = new SimpleDateFormat(AppConstants.DATE_FORMAT).parse(strDate);
		OwnerEntity owner = new OwnerEntity();
		owner.setFirstName("rai");
		owner.setLastName("jung");
		owner.setPhno((long) 465454554);
		owner.setEmail("rai@gmail.com");
		owner.setGender("m");
        owner.setDob(date1);
		OwnerEntity savedInDb = entityManager.persist(owner);

		Optional<OwnerEntity> opt = userEntityRepo.findById(savedInDb.getId());
		OwnerEntity o = opt.get();
		assertThat(o).isEqualTo(savedInDb);
	}

		@Test
		public void testSaveAddressDetails(){
			AddressEntity address=new AddressEntity();
			
			address.setCity("hongkong");
			address.setHno("54/646");
			address.setStreetName("japan");
			address.setZipCode((long) 534343);
			OwnerEntity own=new OwnerEntity();
			address.setOwn(own);
			
			AddressEntity savedInDb =entityManager.persist(address);
			
			Optional<AddressEntity> opt = userEntityRepo2.findById(savedInDb.getId());
		  AddressEntity o=opt.get();
			assertThat(o).isEqualTo(savedInDb);
		}

		
		@Test
		public void testSaveVehicleDetails(){
			VehicleEntity vehicle=new VehicleEntity();
			OwnerEntity own=new OwnerEntity();
			vehicle.setOwn(own);
			vehicle.setName("ford");
			vehicle.setType("wheller");
			 vehicle.setYear("2018");
			
			VehicleEntity savedInDb =entityManager.persist(vehicle);
			
			Optional<VehicleEntity> opt = userEntityRepo3.findById(savedInDb.getId());
		  VehicleEntity o=opt.get();
			assertThat(o).isEqualTo(savedInDb);
		}

		
		@Test
		public void testSaveVehicleRegDetails() throws ParseException{
			VehicleRegEntity vehicleReg=new VehicleRegEntity();
			String strDate="12/06/1995";
			Date date1 = new SimpleDateFormat(AppConstants.DATE_FORMAT).parse(strDate);
			OwnerEntity own=new OwnerEntity();
			vehicleReg.setOwn(own);
			vehicleReg.setRegCenter("kkd");
			vehicleReg.setRegDate(date1);
			
			VehicleRegEntity savedInDb =entityManager.persist(vehicleReg);
			
			Optional<VehicleRegEntity> opt = userEntityRepo4.findById(savedInDb.getId());
			VehicleRegEntity o=opt.get();
			assertThat(o).isEqualTo(savedInDb);
		}

	}
