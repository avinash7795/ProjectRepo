package com.nit.avi.repo;

import java.io.Serializable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.nit.avi.entity.VerifyDetails;

@Repository
public interface UserMasterRepo5 extends JpaRepository<VerifyDetails,Serializable>{

	@Query(value="select id from VerifyDetails where regNum=:uid")
	public Integer findNum(String uid);
 
	
	
}
