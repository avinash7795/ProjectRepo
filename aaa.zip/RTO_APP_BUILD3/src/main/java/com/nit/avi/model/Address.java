package com.nit.avi.model;



import java.util.Date;

import com.nit.avi.entity.OwnerEntity;

import lombok.Data;

@Data

public class Address {
	
	private Integer id;
	
private String hno;
	
private String streetName;
	
private String city;
	
private Long zipCode;
private Date createDate;
private Date updateDate;

private Integer vehicle_owner_id;
private OwnerEntity own;
}
