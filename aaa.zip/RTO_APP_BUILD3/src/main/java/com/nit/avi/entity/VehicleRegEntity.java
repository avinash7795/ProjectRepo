package com.nit.avi.entity;

import java.time.LocalDateTime;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;

import javax.persistence.OneToOne;

import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.CreationTimestamp;

import org.hibernate.annotations.UpdateTimestamp;

import lombok.Data;
@Data
@Entity
@Table(name="VEHICLE_REG_DTLS")
public class VehicleRegEntity {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	//@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "author_generator")
	//@SequenceGenerator(name="author_generator", sequenceName = "VHCL_REGD_ID_SEQ")
	@Column(name="VEHICLE_REG_ID")
	private Integer id;
	@Temporal(TemporalType.DATE)
	@Column(name="REG_DATE")
private Date regDate;
	@Column(name="REG_CENTER")
private String regCenter;
	
	 @CreationTimestamp
	@Column(name="CREATE_DT")
	private LocalDateTime createDate;
	  @UpdateTimestamp
	@Column(name="UPDATE_DT")
	private LocalDateTime updateDate;
    
	
	/*
	 * @GenericGenerator(name = "vehicle_num", strategy =
	 * "com.nit.ravi.generator.VehicleIdGenerator")
	 * 
	 * @GeneratedValue(strategy = GenerationType.SEQUENCE, generator =
	 * "vehicle_num")
	 */
   @Column(name = "VEHICLE_REG_NUM")
	private String regNum;
	
	@OneToOne
	@JoinColumn(name="VEHICLE_OWNER_ID")
	private OwnerEntity own;
	

}
