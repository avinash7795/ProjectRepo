
package com.nit.avi.restcontroller;


import java.util.Optional;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import org.springframework.web.bind.annotation.RestController;

import com.nit.avi.entity.VerifyDetails;
import com.nit.avi.repo.UserMasterRepo5;

@RestController
public class CustomerRestController {

@Autowired
	private UserMasterRepo5 userMasterRepo5;

	@GetMapping(value = "/get", produces = { "application/json", "application/xml" })
public VerifyDetails getUserById(@RequestParam("uid") String uid) {
		System.out.println("get user by id method called");
		Integer id =  userMasterRepo5.findNum(uid);
		int id2=(int)id;
		Optional<VerifyDetails> vd=userMasterRepo5.findById(id2);
		VerifyDetails ss=vd.get();
	return ss;
}
}