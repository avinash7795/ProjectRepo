package com.nit.avi.exceptions;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import lombok.Data;
@Data
@JsonPropertyOrder(value = {"error_type", "code", "error_message"})
public class ErrorResponse
{
	 @JsonProperty("code")
	    int code;
	 @JsonProperty("error_type")
    private String type;
	 @JsonProperty("error_message")
	  private String message;
    
    public ErrorResponse()
    {
        super();
    }
    public ErrorResponse(int code, String message,String type)
    {
        super();
        this.code=code;
        this.type = type;
        this.message = message;
    }
    
   
}