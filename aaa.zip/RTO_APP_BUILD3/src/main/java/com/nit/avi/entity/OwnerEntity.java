package com.nit.avi.entity;


import java.time.LocalDateTime;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import org.springframework.format.annotation.DateTimeFormat;

import lombok.Data;

@Data
@Entity
@Table(name="VEHICLE_OWNER_DTLS")
public class OwnerEntity {
	
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	//@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "author_generator")
	//@SequenceGenerator(name="author_generator", sequenceName = "VHCL_OWNR_ID_SEQ3")
	@Column(name="VEHICLE_OWNER_ID")
	private Integer id;
	@Column(name="FIRST_NAME")
private String firstName;
	@Column(name="LAST_NAME")
private String lastName;
	@Column(name="GENDER")
	private String gender;

	@Column(name="EMAIL")
private String email;
	@Column(name="PHNO")
private Long phno;
	//@JsonFormat(pattern="yyyy-mm-dd",shape=Shape.STRING)
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	@Column(name="DOB")
private Date dob;
	@CreationTimestamp
	@Column(name="CREATE_DT")
	private LocalDateTime createDate;
	@UpdateTimestamp
	@Column(name="UPDATE_DT")
	private LocalDateTime updateDate;
	
	
	


}
