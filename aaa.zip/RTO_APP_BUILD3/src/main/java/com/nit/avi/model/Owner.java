package com.nit.avi.model;



import java.util.Date;

import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.format.annotation.DateTimeFormat;

import lombok.Data;

@Data

public class Owner {
	
private Integer Id;
	
private String firstName;
	
private String lastName;
private String gender;	
private String email;
@DateTimeFormat(pattern = "dd/MM/yyyy")
//@Temporal(TemporalType.DATE)
private Date dob;
private Long phno;
private Date createDate;
private Date updateDate;



}
