package com.nit.avi.model;


import java.util.Date;

import com.nit.avi.entity.OwnerEntity;

import lombok.Data;

@Data

public class Vehicle {
	
 private Integer id; 
  private String type;
  private String year;
  private String name;
  private Date createDate;
  private Date updateDate;
	private OwnerEntity own;
	
  
}
