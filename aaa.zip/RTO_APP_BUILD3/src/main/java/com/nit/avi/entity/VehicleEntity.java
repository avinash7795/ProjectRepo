package com.nit.avi.entity;



import java.time.LocalDateTime;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;

import javax.persistence.OneToOne;

import javax.persistence.Table;


import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import lombok.Data;

@Data
@Entity
@Table(name="VEHICLE_DTLS")
public class VehicleEntity {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	//@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "author_generator")
	//@SequenceGenerator(name="author_generator", sequenceName = "VHCL_DTL_ID_SEQ")
	@Column(name="VEHICLE_DTL_ID")
	private Integer id; 
	@Column(name="VEHICLE_TYPE")
  private String type;
	@Column(name="MFG_YEAR")
  private String year;
	@Column(name="VEHICLE_BRAND")
  private String name;
	 @CreationTimestamp
	@Column(name="CREATE_DT")
	private LocalDateTime createDate;
	   @UpdateTimestamp
	@Column(name="UPDATE_DT")
	private LocalDateTime updateDate;
	   @OneToOne
		@JoinColumn(name="VEHICLE_OWNER_ID")
		private OwnerEntity own;
		
  
}
