package com.nit.avi.constants;

public interface AppConstants {
  public static final String REG_SUCCESS="regSuccess";
  public static final String SUCCESS_MSG="SuccessMsg";
  public static final String FAILURE_MSG="failureMsg";
  public static final String OWNER_REG_VIEW="ownerDetails";
  public static final String OWNER_MODEL_OBJ="owner";
  public static final String VEHICLE_ID="vehicleId";
  public static final String  OWNER_DTLS_VIEW="ownerDetails";
  public static final String Id="id";
  public static final String ADDRESS_MODEL_OBJ="address";
  public static final String  ADDRESS_DTLS_VIEW="AddressDetails";
  public static final String VEHICLE_MODEL_OBJ="vehicle";
  public static final String  VEHICLE_DTLS_VIEW="vehicleDetails";
  public static final String VEHICLEREGDTLS_MODEL_OBJ="regDetails";
  public static final String  VEHICLE_REG_DTLS_VIEW="vehicleRegDetails";
  public static final String ERROR_MSG="sorry something went wrong..! please try again later";
  public static final String GENDERS_VIEW="genders";
  public static final String MALE_MODEL_OBJ="M";
  public static final String FEMALE_MODEL_OBJ="F";
  public static final String REQ_PARAM_ID="uid";
  public static final String DATE_FORMAT="dd/MM/yyyy";
  public static final String CONFIRM_PAGE_VIEW="ConfirmPage";
  
  public static final String FIRSTNAME_MODEL_OBJ="firstName";
  public static final String LASTNAME_MODEL_OBJ="LastName";
  public static final String PHONE_MODEL_OBJ="phone";
  public static final String DATE_MODEL_OBJ="date";
  public static final String GENDER_MODEL_OBJ="gen";
  public static final String HOUSENO_MODEL_OBJ="hno";
  public static final String STREETNAME_MODEL_OBJ="sname";
  public static final String CITY_MODEL_OBJ="city";
  public static final String ZIP_MODEL_OBJ="zip";
  public static final String REGDATE_MODEL_OBJ="rdate";
  public static final String REGCENTER_MODEL_OBJ="rcenter";
  public static final String VEHICLETYPE_MODEL_OBJ="type";
  public static final String VEHICLENAME_MODEL_OBJ="name";
  public static final String VEHICLEYEAR_MODEL_OBJ="year";
  
  }
