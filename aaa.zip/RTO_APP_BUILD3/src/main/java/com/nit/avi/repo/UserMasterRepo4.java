package com.nit.avi.repo;

import java.io.Serializable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.nit.avi.entity.VehicleRegEntity;
@Repository
public interface UserMasterRepo4 extends JpaRepository<VehicleRegEntity,Serializable>{

	
 
	/*
	 * @Query(
	 * value="select * from OwnerEntity o left join VehicleRegEntity e on  e.vehicle_owner_id=o.id where e.id=:uid"
	 * ) public OwnerEntity findEntityById(Integer uid);
	 */
	

     
	/*
	 * @Query(value="select email from UserEntity") public List<String>
	 * findAllEmails();
	 * 
	 * @Query(value="select email from UserEntity where userId=:uid") public String
	 * findEmailById(Integer uid);
	 */
	/*
	 * @Query("select * from UserEntity  where country like ?1") public
	 * List<UserEntity> findByCountryContains(String country);
	 */
}
