package com.nit.avi.model;

import java.util.Date;

import com.nit.avi.entity.OwnerEntity;

import lombok.Data;
@Data
public class VehicleRegDtls {
private Integer id;
private Date regDate;
private String regCenter;
private Date createDate;
private Date updateDate;
private String regNum;
private OwnerEntity own;
}
