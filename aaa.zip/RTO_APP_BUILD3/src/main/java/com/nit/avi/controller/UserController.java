package com.nit.avi.controller;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Optional;

import org.apache.log4j.Appender;
import org.apache.log4j.FileAppender;
import org.apache.log4j.Layout;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.apache.log4j.SimpleLayout;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.nit.avi.constants.AppConstants;
import com.nit.avi.entity.AddressEntity;
import com.nit.avi.entity.OwnerEntity;
import com.nit.avi.entity.VehicleEntity;
import com.nit.avi.entity.VehicleRegEntity;
import com.nit.avi.entity.VerifyDetails;
import com.nit.avi.exceptions.UserNotFoundException;
import com.nit.avi.generator.RandomString;
import com.nit.avi.model.Address;
import com.nit.avi.model.Owner;
import com.nit.avi.model.Vehicle;
import com.nit.avi.model.VehicleRegDtls;
import com.nit.avi.repo.UserMasterRepo;
import com.nit.avi.repo.UserMasterRepo2;
import com.nit.avi.repo.UserMasterRepo3;
import com.nit.avi.repo.UserMasterRepo4;
import com.nit.avi.repo.UserMasterRepo5;

@Controller
public class UserController {
	static Logger logger = Logger.getLogger(UserController.class.getName());
	static String properties = System.getProperty("user.dir") + File.separator + "log4j.properties";

	public static VerifyDetails verify = new VerifyDetails();
	public static Integer it = 0;
	public static Integer it2 = 0;
	public static Integer it3 = 0;
	public static Integer it4 = 0;
	public static OwnerEntity saveRepo = null;
	public static AddressEntity saveRepo2 = null;
	public static VehicleEntity saveRepo3 = null;
	public static Integer ownerId = 0;
	public static Integer ownerId2 = 0;
	public static Integer ownerId3 = 0;
	public static OwnerEntity own = null;
	public static AddressEntity add = null;
	public static VehicleEntity vh = null;
	public static String number = null;
	@Autowired
	private AppProperties appProps;

	@Autowired
	private UserMasterRepo userEntityRepo;
	@Autowired
	private UserMasterRepo2 userEntityRepo2;
	@Autowired
	private UserMasterRepo3 userEntityRepo3;
	@Autowired
	private UserMasterRepo4 userEntityRepo4;
	@Autowired
	private UserMasterRepo5 userEntityRepo5;

	public UserController() {
		System.out.println("user controller::constructor");
	}

	/**
	 * this method is used to display RTO ui
	 * 
	 * @param model
	 * @param user
	 * @return
	 */
	@RequestMapping(value = "/")
	public String loadFormData() {
		loadLog4jProperties();
		logger.info("index page loaded successfully");
		return "index";
	}

	/**
	 * This method is used to load log4j properties
	 */
	public void loadLog4jProperties() {
		// log4j properities
		PropertyConfigurator.configure(properties);
		Layout layout = new SimpleLayout();
		Appender appender;
		try {
			appender = new FileAppender(layout, "applog.log", false);
			logger.addAppender(appender);
		} catch (Exception e) {
			e.printStackTrace();
		}

		// end of log4j
	}

	/**
	 * display form in ui
	 * 
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/register")
	public String loadRegForm(Model model) {
		//loadLog4jProperties();
		logger.info("Register page loaded successfully");
		Owner ownerObj = new Owner();
		loadGenderData(model);
		model.addAttribute(AppConstants.OWNER_MODEL_OBJ, ownerObj);

		return AppConstants.OWNER_DTLS_VIEW;
	}

	/**
	 * This method is used to register the vehicle owner details
	 * 
	 * @param owner
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/ownerDetails")
	public String loadRegForm4(@ModelAttribute(AppConstants.OWNER_MODEL_OBJ) Owner owner, Model model) {
		//loadLog4jProperties();
		logger.info("owner details page loaded successfully");
		if (ownerId != 0) {
			Optional<OwnerEntity> optEntity = userEntityRepo.findById(ownerId);
			OwnerEntity entity = optEntity.get();
			BeanUtils.copyProperties(owner, entity);
			entity.setId(ownerId);
			saveRepo = userEntityRepo.save(entity);
			ownerDblOp(owner);
			it = saveRepo.getId();
		} else {
			OwnerEntity ownEntity = new OwnerEntity();
			BeanUtils.copyProperties(owner, ownEntity);
			saveRepo = userEntityRepo.save(ownEntity);
			ownerDblOp(owner);
			it = saveRepo.getId();
		}
		if (saveRepo.getId() != 0) {

			Address address = new Address();
			model.addAttribute(AppConstants.ADDRESS_MODEL_OBJ, address);
			model.addAttribute(AppConstants.Id, it);
			return AppConstants.ADDRESS_DTLS_VIEW;

		} else {
			logger.warn(" error  from loadRegForm4 method");
			throw new UserNotFoundException(AppConstants.ERROR_MSG);
		}

	}

	/**
	 * This method is used to insert the ownerdata into verifyDtsl table
	 * 
	 * @param owner
	 */
	public void ownerDblOp(Owner owner) {
		own = saveRepo;
		verify.setFirstName(owner.getFirstName());
		verify.setLastName(owner.getLastName());
		verify.setGender(owner.getGender());
		verify.setBirth(owner.getDob());
		verify.setMail(owner.getEmail());
		verify.setPhno(owner.getPhno());
	}

	/**
	 * This method is used to load the vehicle owner address Details
	 * 
	 * @param address
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/AddressDetails")
	public String loadRegForm3(@ModelAttribute(AppConstants.ADDRESS_MODEL_OBJ) Address address, Model model) {
		//loadLog4jProperties();
		logger.info("address details page loaded successfully");
		if (ownerId2 != 0) {
			Optional<AddressEntity> optEntity = userEntityRepo2.findById(ownerId2);
			AddressEntity entity = optEntity.get();
			BeanUtils.copyProperties(address, entity);
			entity.setId(ownerId2);
			entity.setOwn(own);
			saveRepo2 = userEntityRepo2.save(entity);
			addressDblOp(address);
			it2 = saveRepo2.getId();

		} else {
			AddressEntity addEntity = new AddressEntity();
			BeanUtils.copyProperties(address, addEntity);
			addEntity.setOwn(own);
			saveRepo2 = userEntityRepo2.save(addEntity);
			addressDblOp(address);
			it2 = saveRepo2.getId();
		}

		if (saveRepo2.getId() != 0) {
			Vehicle vehicle = new Vehicle();
			model.addAttribute(AppConstants.VEHICLE_MODEL_OBJ, vehicle);
			model.addAttribute(AppConstants.Id, it2);
			return AppConstants.VEHICLE_DTLS_VIEW;
		} else {
			logger.warn(" error  from loadRegForm3 method");
			throw new UserNotFoundException(AppConstants.ERROR_MSG);
		}
	}

	/**
	 * This method is used to insert the addressdata into verifyDtsl table
	 * 
	 * @param owner
	 */
	public void addressDblOp(Address address) {

		verify.setHouse(address.getHno());
		verify.setCityName(address.getCity());
		verify.setStreet(address.getStreetName());
		verify.setZip(address.getZipCode());

	}

	/**
	 * This method is used to register the vehicle details
	 * 
	 * @param vehicle
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/vehicleDetails")
	public String loadRegForm2(@ModelAttribute(AppConstants.VEHICLE_MODEL_OBJ) Vehicle vehicle, Model model) {
		//loadLog4jProperties();
		logger.info("vehicle details page loaded successfully");
		if (ownerId3 != 0) {
			Optional<VehicleEntity> optEntity = userEntityRepo3.findById(ownerId3);
			VehicleEntity entity = optEntity.get();
			BeanUtils.copyProperties(vehicle, entity);
			entity.setId(ownerId3);
			entity.setOwn(own);
			saveRepo3 = userEntityRepo3.save(entity);
			vehicleDblOp(vehicle);
			it3 = saveRepo3.getId();

		} else {
			VehicleEntity vehicleObj = new VehicleEntity();
			BeanUtils.copyProperties(vehicle, vehicleObj);
			vehicleObj.setOwn(own);
			saveRepo3 = userEntityRepo3.save(vehicleObj);
			vehicleDblOp(vehicle);
			it3 = saveRepo3.getId();
		}

		if (saveRepo3.getId() != 0) {

			VehicleRegDtls regDetails = new VehicleRegDtls();
			model.addAttribute(AppConstants.VEHICLEREGDTLS_MODEL_OBJ, regDetails);
			model.addAttribute(AppConstants.Id, it3);
			return AppConstants.VEHICLE_REG_DTLS_VIEW;
		} else {
			logger.warn(" error  from loadRegForm2 method");
			throw new UserNotFoundException(AppConstants.ERROR_MSG);
		}

	}

	/**
	 * This method is used to insert the vehicledata into verifyDtsl table
	 * 
	 * @param owner
	 */
	public void vehicleDblOp(Vehicle vehicle) {

		verify.setTypeVeh(vehicle.getType());
		verify.setBrand(vehicle.getName());
		verify.setYr(vehicle.getYear());

	}

	/**
	 * this method is used to register the vehicle registration details
	 * 
	 * @param regDetails
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/vehicleRegDetails")
	public String loadRegForm5(@ModelAttribute(AppConstants.VEHICLEREGDTLS_MODEL_OBJ) VehicleRegDtls regDetails,
			Model model) {
		//loadLog4jProperties();
		logger.info("vehicle Registration details page loaded successfully");
		VehicleRegEntity regEntity = new VehicleRegEntity();
		number = RandomString.getAlphaNumericString(2) + "-" + RandomString.getAlphaNumericString(3);
		regDetails.setRegNum(number);
		BeanUtils.copyProperties(regDetails, regEntity);
		regEntity.setOwn(own);
		VehicleRegEntity saveRep = userEntityRepo4.save(regEntity);

		verify.setRegDt(regDetails.getRegDate());
		verify.setRgCenter(regDetails.getRegCenter());
		verify.setRegNum(number);
		it4 = saveRep.getId();
		if (saveRep.getId() != 0) {

			model.addAttribute(AppConstants.FIRSTNAME_MODEL_OBJ, verify.getFirstName());
			model.addAttribute(AppConstants.LASTNAME_MODEL_OBJ, verify.getLastName());
			model.addAttribute(AppConstants.PHONE_MODEL_OBJ, verify.getPhno());
			model.addAttribute(AppConstants.DATE_MODEL_OBJ, verify.getBirth());
			model.addAttribute(AppConstants.GENDER_MODEL_OBJ, verify.getGender());
			model.addAttribute(AppConstants.HOUSENO_MODEL_OBJ, verify.getHouse());
			model.addAttribute(AppConstants.STREETNAME_MODEL_OBJ, verify.getStreet());
			model.addAttribute(AppConstants.CITY_MODEL_OBJ, verify.getCityName());
			model.addAttribute(AppConstants.ZIP_MODEL_OBJ, verify.getZip());
			model.addAttribute(AppConstants.REGDATE_MODEL_OBJ, verify.getRegDt());
			model.addAttribute(AppConstants.REGCENTER_MODEL_OBJ, verify.getRgCenter());
			model.addAttribute(AppConstants.VEHICLETYPE_MODEL_OBJ, verify.getTypeVeh());
			model.addAttribute(AppConstants.VEHICLENAME_MODEL_OBJ, verify.getBrand());
			model.addAttribute(AppConstants.VEHICLEYEAR_MODEL_OBJ, verify.getYr());

			model.addAttribute(AppConstants.Id, it4);

			return AppConstants.CONFIRM_PAGE_VIEW;
		} else {
			logger.warn(" error  from loadRegForm5 method");
			throw new UserNotFoundException(AppConstants.ERROR_MSG);
		}

	}

	/**
	 * this method is used to handle user creation in page
	 * 
	 * @param user
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/regForm", method = RequestMethod.POST)
	public String formSubmit(Model model, RedirectAttributes attributes) {
		//loadLog4jProperties();
		logger.info("success dispplay  page loaded successfully");
		userEntityRepo5.save(verify);
		String msg = appProps.getMessages().get(AppConstants.REG_SUCCESS);
		if (number != null) {
			// model.addAttribute(AppConstants.SUCCESS_MSG,msg);
			attributes.addFlashAttribute(AppConstants.SUCCESS_MSG, msg);
			attributes.addFlashAttribute(AppConstants.VEHICLE_ID, number);
		} else {
			logger.warn(" error  from formSubmit method");
			throw new UserNotFoundException(AppConstants.ERROR_MSG);
		}
		return "redirect:/registerSuccess";
		// return AppConstants.USER_REG_VIEW;
	}

	/**
	 * this method is used to display success msg post registration
	 * 
	 * @param model
	 */
	@RequestMapping(value = "/registerSuccess")
	public String registerSuccess(Model model) {
		loadLog4jProperties();
		logger.info("register success  method loaded successfully");
		Owner ownerObj = new Owner();

		model.addAttribute(AppConstants.OWNER_MODEL_OBJ, ownerObj);

		return AppConstants.OWNER_REG_VIEW;
	}

	/**
	 * This method is load the genders data in ui
	 * 
	 * @param model
	 */
	public static void loadGenderData(Model model) {
		
		java.util.List<String> genders = new ArrayList<String>();
		genders.add(AppConstants.MALE_MODEL_OBJ);
		genders.add(AppConstants.FEMALE_MODEL_OBJ);
		model.addAttribute(AppConstants.GENDERS_VIEW, genders);
	}

	/**
	 * This method is used to load when previous button is clicked in Address
	 * details page
	 * 
	 * @param model
	 * @param userId
	 * @return
	 * @throws Exception
	 */
	@RequestMapping(value = "/OwnerDetails")
	public String editOwnerDetails(Model model, @RequestParam(AppConstants.REQ_PARAM_ID) Integer userId)
			throws Exception {
		//loadLog4jProperties();
		logger.info("edit owner details page loaded successfully");
		ownerId = userId;
		if (userId != 0) {

			Optional<OwnerEntity> optEntity = userEntityRepo.findById(userId);
			// Date date=userEntityRepo.getDate(userId);

			if (optEntity.isPresent()) {
				OwnerEntity entity = optEntity.get();
				Date date = entity.getDob();
				SimpleDateFormat formatter = new SimpleDateFormat(AppConstants.DATE_FORMAT);
				String strDate = formatter.format(date);
				System.out.println(strDate);
				Date date1 = new SimpleDateFormat(AppConstants.DATE_FORMAT).parse(strDate);
				Owner owner = new Owner();
				BeanUtils.copyProperties(entity, owner);
				owner.setDob(date1);
				model.addAttribute(AppConstants.OWNER_MODEL_OBJ, owner);
				loadGenderData(model);

			}
		} else {
			logger.warn(" error  from editOwnerDetails method");
			throw new UserNotFoundException(AppConstants.ERROR_MSG);
		}
		return AppConstants.OWNER_DTLS_VIEW;

	}

	/**
	 * This method is used to load when previous button is clicked in vehcile
	 * details page
	 * 
	 * @param model
	 * @param userId
	 * @return
	 */

	@RequestMapping(value = "/addressDetails")
	public String editAddressDetails(Model model, @RequestParam(AppConstants.REQ_PARAM_ID) Integer userId) {
		//loadLog4jProperties();
		logger.info("edit address details page loaded successfully");
		ownerId2 = userId;
		if (userId != 0) {

			Optional<AddressEntity> optEntity = userEntityRepo2.findById(userId);
			if (optEntity.isPresent()) {
				AddressEntity entity = optEntity.get();
				System.out.println(entity.getZipCode());
				Address address = new Address();
				BeanUtils.copyProperties(entity, address);
				model.addAttribute(AppConstants.ADDRESS_MODEL_OBJ, address);

			}
		} else {
			logger.warn(" error  from edit address details method");
			throw new UserNotFoundException(AppConstants.ERROR_MSG);
		}
		return AppConstants.ADDRESS_DTLS_VIEW;

	}

	/**
	 * This method is used to load when previous button is clicked in vehicleReg
	 * details page
	 * 
	 * @param model
	 * @param userId
	 * @return
	 */
	@RequestMapping(value = "/VehicleDetails")
	public String editVehicleDetails(Model model, @RequestParam(AppConstants.REQ_PARAM_ID) Integer userId) {
		//loadLog4jProperties();
		logger.info("edit vehicle details page loaded successfully");
		ownerId3 = userId;
		if (userId != 0) {

			Optional<VehicleEntity> optEntity = userEntityRepo3.findById(userId);
			if (optEntity.isPresent()) {
				VehicleEntity entity = optEntity.get();
				Vehicle vehicle = new Vehicle();
				BeanUtils.copyProperties(entity, vehicle);
				model.addAttribute(AppConstants.VEHICLE_MODEL_OBJ, vehicle);
			}
		} else {
			logger.warn(" error  from editVehicleDetails method");
			throw new UserNotFoundException(AppConstants.ERROR_MSG);
		}
		return AppConstants.VEHICLE_DTLS_VIEW;

	}

	/**
	 * This method is used to load when previous button is clicked in confirm
	 * details page
	 * 
	 * @param model
	 * @param userId
	 * @return
	 */

	@RequestMapping(value = "/VehicleRegDetails")
	public String editVehicleRegDetails(Model model, @RequestParam(AppConstants.REQ_PARAM_ID) Integer userId) {
		//loadLog4jProperties();
		logger.info("edit vehicleRegistration details page loaded successfully");
		if (userId != 0) {

			Optional<VehicleRegEntity> optEntity = userEntityRepo4.findById(userId);
			if (optEntity.isPresent()) {
				VehicleRegEntity entity = optEntity.get();
				VehicleRegDtls vehDtls = new VehicleRegDtls();
				BeanUtils.copyProperties(entity, vehDtls);
				model.addAttribute(AppConstants.VEHICLEREGDTLS_MODEL_OBJ, vehDtls);

			}
		} else {
			logger.warn(" error  from editVehicleRegDetails method");
			throw new UserNotFoundException(AppConstants.ERROR_MSG);
		}
		return AppConstants.VEHICLE_REG_DTLS_VIEW;
	}

}
