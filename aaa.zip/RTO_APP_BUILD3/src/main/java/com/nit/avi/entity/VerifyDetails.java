package com.nit.avi.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import lombok.Data;
@Data
@Entity
@Table(name="VERIFY_DTLS")
@XmlRootElement
@XmlAccessorType(XmlAccessType.FIELD)
public class VerifyDetails {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="ID")
	@XmlElement
	private Integer id;
	@Column(name="FIRST_NAME")
	@XmlElement
	private String firstName;
	@Column(name="LAST_NAME")
	@XmlElement
	private String lastName;
	@Column(name="GENDER")
	@XmlElement
	private String gender;	
	@Column(name="MAIL")
	@XmlElement
	private String mail;
	@Column(name="BIRTH")
	@XmlElement
	private Date birth;
	@Column(name="PHNO")
	@XmlElement
	private Long phno;
	@Column(name="HOUSE")
	@XmlElement
	private String house;
	@Column(name="STREET")
	@XmlElement
	private String street;
	@Column(name="CITY")
	@XmlElement
	private String cityName;
	@Column(name="ZIP")
	@XmlElement
	private Long zip;
	@Column(name="VEH_TYPE")
	@XmlElement
	private String typeVeh;
	@Column(name="YEAR")
	@XmlElement
	private String yr;
	@Column(name="BRAND")
	@XmlElement
	private String brand;
	@Column(name="REG_DT")
	@XmlElement
	private Date regDt;
	@Column(name="REG_CENTER")
	@XmlElement
	private String rgCenter;
	@Column(name="REG_NUM")
	@XmlElement
	private String regNum;

}
