package com.nit.avi.exceptions;


import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
@Controller
@ControllerAdvice
public class AppExceptionHandler {
 public AppExceptionHandler() {
	System.out.println("app exception handler executed");
}
    
    @ExceptionHandler(value=NullPointerException.class)
	public String handleException(Model model) {
		model.addAttribute("errorMsg","sorry,something went wrong try some later");
		return "errorPage";
	}
   
    @ExceptionHandler(value=UserNotFoundException.class)
	public String handleExceptionByMethod(Model model) {
    	model.addAttribute("errorMsg","sorry,something went wrong try some later");
		return "errorPage";
	}



  @ExceptionHandler(value =  HttpRequestMethodNotSupportedException.class)
  public ResponseEntity<ErrorResponse> methodNotSupportErrorHandler(HttpServletRequest req, Exception e) throws Exception {
	  ErrorResponse error = new ErrorResponse(400, "BadRequestException", "Method not supported");
      return new ResponseEntity<ErrorResponse>(error, HttpStatus.BAD_REQUEST);
  }
    
    @ExceptionHandler(value = { Exception.class })
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public ErrorResponse unKnownException(Exception ex)
    {
        return new ErrorResponse(404, "Employee Not Found", null);
    }
}