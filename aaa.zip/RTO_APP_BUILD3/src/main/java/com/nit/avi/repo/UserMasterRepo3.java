package com.nit.avi.repo;

import java.io.Serializable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.nit.avi.entity.VehicleEntity;

@Repository
public interface UserMasterRepo3 extends JpaRepository<VehicleEntity,Serializable>{

	
	

     
	/*
	 * @Query(value="select email from UserEntity") public List<String>
	 * findAllEmails();
	 * 
	 * @Query(value="select email from UserEntity where userId=:uid") public String
	 * findEmailById(Integer uid);
	 */
	/*
	 * @Query("select * from UserEntity  where country like ?1") public
	 * List<UserEntity> findByCountryContains(String country);
	 */
}
