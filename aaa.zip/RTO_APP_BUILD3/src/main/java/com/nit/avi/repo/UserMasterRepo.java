package com.nit.avi.repo;

import java.io.Serializable;
import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;

import com.nit.avi.entity.OwnerEntity;
import com.nit.avi.model.Owner;

@Repository
public interface UserMasterRepo extends JpaRepository<OwnerEntity,Serializable>{

	

	
	/*
	 * @Modifying
	 * 
	 * @Query(value=
	 * "update OwnerEntity o set o.firstName=:myfrst where o.id=:myId") public
	 * Integer updateTable(String myfrst, Integer myId);
	 */
}
