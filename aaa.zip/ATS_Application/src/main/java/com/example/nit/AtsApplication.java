package com.example.nit;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import org.springframework.web.bind.annotation.RestController;

import com.example.nit.pojo.MailRequest;
import com.example.nit.pojo.MailResponse;
import com.example.nit.service.EmailService;

@SpringBootApplication
/*
 * (scanBasePackages={ "com.example.nit.service","com.example.nit.controller"})
 */
@RestController
public class AtsApplication {

	@Autowired
	private EmailService service;

	@PostMapping("/sendingEmail")
	public MailResponse sendEmail(@RequestBody MailRequest request) {
		Map<String, Object> model = new HashMap<>();
		model.put("Name", request.getName());
		model.put("location", "Bangalore,India");
		model.put("password",request.getTempPwd());
		return service.sendEmail(request, model);

	}

	public static void main(String[] args) {
		SpringApplication.run(AtsApplication.class, args);
	}

}
