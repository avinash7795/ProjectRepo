package com.example.nit.pojo;

import lombok.Data;
/**
 * This class is used to handle the messages send to mail receiptent
 * @author user
 *
 */
@Data
public class MailRequest {
	
	private String name;
	private String to;
	private String from;
	private String subject;
    private String tempPwd;
}
