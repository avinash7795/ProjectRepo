package com.example.nit.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.Data;

@Component
@Data
@ConfigurationProperties(prefix="formapp")
@EnableConfigurationProperties
public class AppProperties {
   private Map<String,String> messages=new HashMap<String,String>();


}
