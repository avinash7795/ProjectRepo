package com.example.nit.restController;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * This class is used to send email to particular receiptent
 * @author user
 *
 */
public class EmailSender {
	
    /**
     * This method acts as Restclient for java to send mail as a post request
     * @param email
     * @param name
     * @param pwd
     * @throws IOException
     */
	public static void POSTRequest(String email,String name,String pwd) throws IOException {
		

		final String POST_PARAMS = "{\r\n" + " \"to\":\"" + email + "\",\r\n"
				+ " \"from\":\"kishoreravi225@gmail.com\",\r\n" + " \"subject\":\"ATS Account Registration\",\r\n"
				+ " \"name\":\"" + name + "\",\r\n" + " \"tempPwd\":\"" + pwd + "\"\r\n" + "}";

		
		System.out.println(POST_PARAMS);
		URL obj = new URL("http://localhost:9090/SBFormApp/sendingEmail");
		HttpURLConnection postConnection = (HttpURLConnection) obj.openConnection();
		postConnection.setRequestMethod("POST");
		//postConnection.setRequestProperty("userId", "a1bcdefgh");
		postConnection.setRequestProperty("Content-Type", "application/json");
		postConnection.setDoOutput(true);
		OutputStream os = postConnection.getOutputStream();
		os.write(POST_PARAMS.getBytes());
		os.flush();
		os.close();
		int responseCode = postConnection.getResponseCode();
		System.out.println("POST Response Code :  " + responseCode);
		System.out.println("POST Response Message : " + postConnection.getResponseMessage());
		if (responseCode == 200) { // success
			BufferedReader in = new BufferedReader(new InputStreamReader(postConnection.getInputStream()));
			String inputLine;
			StringBuffer response = new StringBuffer();
			while ((inputLine = in.readLine()) != null) {
				response.append(inputLine);
			}
			in.close();
			// print result
			System.out.println(response.toString());
		} else {
			System.out.println("Email sending failed");
		}
	}

}
