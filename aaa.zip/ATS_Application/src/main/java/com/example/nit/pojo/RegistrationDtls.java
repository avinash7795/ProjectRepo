package com.example.nit.pojo;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import lombok.Data;

/**
 * This class is used to store the Registration form values in jsp page
 * 
 * @author user
 *
 */

@Data
public class RegistrationDtls {
	private Integer id;

	private String firstName;

	private String lastName;
	private String gender;
	private String email;
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	private Date dob;
	private Long phno;
	private Date createDate;
	private Date updateDate;

	private String status;
	private String role;

	private String password;

	private String tempPwd;
	private String confirmPwd;
	private String newPwd;

	private String username;
}
