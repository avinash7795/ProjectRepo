package com.example.nit.service;

import org.springframework.stereotype.Service;

import com.example.nit.entity.RegistrationDtlsEntity;
/**
 * This class is used as service layer to interact with dao class
 * @author user
 *
 */

public interface MyService {
 public RegistrationDtlsEntity saveAccount(RegistrationDtlsEntity entity);
 public Integer findIdByEmail(String email);
 public RegistrationDtlsEntity finding(Integer id);
}
