package com.example.nit.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.nit.entity.RegistrationDtlsEntity;
import com.example.nit.repo.UserMasterRepo;
/**
 * This class is used as serviceClass Implementation methods to interact with dao
 * @author user
 *
 */
@Service
public class MyServiceImpl implements MyService {

	@Autowired
	private UserMasterRepo userEntityRepo;

	public RegistrationDtlsEntity saveAccount(RegistrationDtlsEntity Regentity) {

		return userEntityRepo.save(Regentity);
	}

	public Integer findIdByEmail(String email) {
		
		return userEntityRepo.findNum(email);
	}
	
	public RegistrationDtlsEntity finding(Integer id) {
		
		Optional<RegistrationDtlsEntity> opt=userEntityRepo.findById(id);
		RegistrationDtlsEntity regEntity=opt.get();
		return regEntity;
	}

}
