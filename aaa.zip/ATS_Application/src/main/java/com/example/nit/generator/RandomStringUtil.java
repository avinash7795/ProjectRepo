package com.example.nit.generator;

/**
 * this class is used to generate random string value
 * 
 * @author user
 *
 */
public final class RandomStringUtil {
	// public static final Logger LOGGER =
	// Logger.getLogger(UserController.class.getName());
	// public static final String PROPERTIES = System.getProperty("user.dir") +
	// File.separator + "log4j.properties";

	private RandomStringUtil() {
		// LOGGER.info("Random string:constructor called");
		throw new AssertionError("Instantiating utility class...Random string");

	}

	public static final String ALPHANUMERICSTRING = "ABCDEFGHIJKLMNOPQRSTUVWXYZ" + "0123456789";

	public static String getAlphaNumericString(int n) {
		StringBuilder sb = new StringBuilder(n);
		for (int i = 0; i < n; i++) {
			int index = (int) (ALPHANUMERICSTRING.length() * Math.random());
			sb.append(ALPHANUMERICSTRING.charAt(index));
		}
		return sb.toString();
	}

}
