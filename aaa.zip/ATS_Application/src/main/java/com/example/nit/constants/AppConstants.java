package com.example.nit.constants;

public class AppConstants {
	public static final String SUCCESS_MSG="SuccessMsg";
	public static final String FAILURE_MSG="failureMsg";
	public static final String REG_SUCCESS="regSuccess";
	public static final String ACCOUNT_SUCCESS="AccountSuccess";
	public static final String PASSWORD_CHECK="passwordCheck";
	public static final String TEMPPASSWORD_CHECK="TempPasswordCheck";
	public static final String ERROR_MSG="sorry something went wrong..! please try again later";
	public static final String VALIDATE_MSG="validationCheck";
}
