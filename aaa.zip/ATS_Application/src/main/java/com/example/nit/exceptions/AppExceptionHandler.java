package com.example.nit.exceptions;

import java.io.File;
import org.apache.log4j.Appender;
import org.apache.log4j.FileAppender;
import org.apache.log4j.Layout;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.apache.log4j.SimpleLayout;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.example.nit.controller.MyController;

/**
 * This class is used to handle the overall exceptions in the project
 * 
 * @author user
 *
 */
@RestControllerAdvice
@Controller
@ControllerAdvice
public class AppExceptionHandler {
	public static final Logger LOGGER = Logger.getLogger(MyController.class.getName());
	 public static final String PROPERTIES = System.getProperty("user.dir") +File.separator + "log4j.properties";

	public AppExceptionHandler() {
		LOGGER.info("AppException handler class executed ::constructor");
	}

	/**
	 * This method is used to load log4j properties
	 */
	public void loadLog4jProperties() {
		// log4j properities
		PropertyConfigurator.configure(PROPERTIES);
		Layout layout = new SimpleLayout();
		Appender appender;
		try {
			appender = new FileAppender(layout, "applog.log", false);
			LOGGER.addAppender(appender);
		} catch (Exception e) {
			e.printStackTrace();
		}

		// end of log4j
	}


	/**
	 * This method is used to handle the null pointer exception in any class in the
	 * project
	 * 
	 * @param model
	 * @return
	 */
	@ExceptionHandler(value = NullPointerException.class)
	public String handleException(Model model) {
		model.addAttribute("errorMsg", "sorry,something went wrong try some later");
		return "errorPage";
	}

	/**
	 * This method is used to handle the custom exception in any class in the
	 * project
	 * 
	 * @param model
	 * @return
	 */
	@ExceptionHandler(value = UserNotFoundException.class)
	public String handleExceptionByMethod(Model model) {
		model.addAttribute("errorMsg", "sorry,something went wrong try some later");
		return "errorPage";
	}

	/**
	 * This method is used to handle the HTTP 400 bad request exception in any class
	 * in the project
	 * 
	 * @param model
	 * @return
	 */

	/*
	 * @ExceptionHandler(value = HttpRequestMethodNotSupportedException.class)
	 * public ResponseEntity<ErrorResponse>
	 * methodNotSupportErrorHandler(HttpServletRequest req, Exception e) throws
	 * Exception { ErrorResponse error = new ErrorResponse(400,
	 * "BadRequestException", "Method not supported"); return new
	 * ResponseEntity<ErrorResponse>(error, HttpStatus.BAD_REQUEST); }
	 */

	@ExceptionHandler(value = { HttpRequestMethodNotSupportedException.class })
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	public ErrorResponse badRequestException(Exception ex) {
		return new ErrorResponse(400, "Please check your url", null);
	}
	/**
	 * This method is used to handle the 404 resource not found exception in any
	 * class in the project
	 * 
	 * @param model
	 * @return
	 */
	@ExceptionHandler(value = { Exception.class })
	@ResponseStatus(HttpStatus.NOT_FOUND)
	public ErrorResponse unKnownException(Exception ex) {
		return new ErrorResponse(404, "Page Not Found", null);
	}
}