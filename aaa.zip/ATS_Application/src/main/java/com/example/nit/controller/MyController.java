package com.example.nit.controller;

import java.io.File;
import java.io.IOException;
import java.util.Optional;

import org.apache.log4j.Appender;
import org.apache.log4j.FileAppender;
import org.apache.log4j.Layout;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.apache.log4j.SimpleLayout;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.example.nit.constants.AppConstants;
import com.example.nit.entity.RegistrationDtlsEntity;
import com.example.nit.exceptions.UserNotFoundException;
import com.example.nit.generator.RandomStringUtil;

import com.example.nit.pojo.RegistrationDtls;
import com.example.nit.repo.UserMasterRepo;
import com.example.nit.restController.EmailSender;

/**
 * This class is used to handle request coming from frontend
 * 
 * @author user
 *
 */
@Controller
public class MyController {
	public static final Logger LOGGER = Logger.getLogger(MyController.class.getName());
	public static final String PROPERTIES = System.getProperty("user.dir") + File.separator + "log4j.properties";

	/*
	 * This variable is used to store email of the user
	 */
	public static String email = null;
	/*
	 * This variable is used to store temporary password of the user
	 */
	public static String tempPwd = null;
	/*
	 * This variable is used to store all the Registration details of the user
	 */
	RegistrationDtlsEntity saveRepo = null;
	/*
	 * This variable is used to interact with database
	 */
//	@Autowired(required=true)
//	private MyService myService;
	
	/*
	 * This variable is used to interact with database
	 */
	@Autowired(required=true)
	private UserMasterRepo userEntityRepo;
	/*
	 * This variable is used to handle the string in controller
	 */
	@Autowired
	private AppProperties appProps;
	
	
	/**
	 * This method is used to load log4j properties
	 */
	public void loadLog4jProperties() {
		// log4j properities
		PropertyConfigurator.configure(PROPERTIES);
		Layout layout = new SimpleLayout();
		Appender appender;
		try {
			appender = new FileAppender(layout, "applog.log", false);
			LOGGER.addAppender(appender);
		} catch (Exception e) {
			e.printStackTrace();
		}

		// end of log4j
	}


	/**
	 * This method is used to load front end index page of the project and user
	 * login page
	 * 
	 * @param model
	 * @return index page
	 */
	@RequestMapping(value = "/",method=RequestMethod.GET)
	public String loadFormData(Model model) {
		loadLog4jProperties();
		LOGGER.info("index page loaded succcessfully");
		RegistrationDtls register = new RegistrationDtls();
         model.addAttribute("register", register);
		return "index";
	}

	/**
	 * This method is used to validate the credentials and display corresponding page according to role
	 * 
	 * @param regEntity
	 * @param model
	 * @return
	 */
	
	  @RequestMapping(value="/validating",method=RequestMethod.POST) 
	  public String checkCredentials(@ModelAttribute("register")RegistrationDtlsEntity regEntity,Model model,RedirectAttributes attributes) {
		  LOGGER.info("Login page validation method called");
		  String msg = appProps.getMessages().get(AppConstants.VALIDATE_MSG);
		  
		  String username=regEntity.getUsername(); 
		  String password=regEntity.getPassword(); Integer
	       // id=myService.findIdByEmail(username);
		  id=userEntityRepo.findNum(username);
		  //RegistrationDtlsEntity entity=myService.finding(id); String role=entity.getRole();
		  Optional<RegistrationDtlsEntity> opt=userEntityRepo.findById(id);
		  RegistrationDtlsEntity entity=opt.get();
		  String role=entity.getRole();
	  if(username.equals(entity.getUsername())&&password.equals(entity.getPassword( ))) {
		  if(role.equals("user")) { 
			  //display user page
			  return "UserPage"; 
			 }else if(role.equals("admin")) { 
		    //display admin page 
	         }else { 
		     //display agency page
	         }
	  
	  }else { 
		  //error msg
		  attributes.addFlashAttribute(AppConstants.SUCCESS_MSG, msg);
	  } return "";
	  
	 }
	
	 /**
	  * This method is used to load the Register page 
	  * @param model
	  * @return
	  */
	@RequestMapping(value = "/register")
	public String loadRegForm(Model model) {
	
		LOGGER.info("registration page loaded succcessfully");
		RegistrationDtls regDtls = new RegistrationDtls();
		model.addAttribute("register", regDtls);

		return "RegistrationDtls";
	}

	/**
	 * This method is used to handle the post request when user submits form
	 * 
	 * @param regDtls
	 * @param model
	 * @param attributes
	 * @return RegistrationDtls page
	 * @throws IOException
	 */
	@RequestMapping(value = "/registerDetails", method = RequestMethod.POST)
	public String registerDetails(@ModelAttribute("register") RegistrationDtls regDtls, Model model,
			RedirectAttributes attributes) throws IOException {
		LOGGER.info("saving register details method called");
		String msg = appProps.getMessages().get(AppConstants.REG_SUCCESS);
		RegistrationDtlsEntity regEntity = new RegistrationDtlsEntity();
		BeanUtils.copyProperties(regDtls, regEntity);
		regEntity.setRole("user");
		regEntity.setStatus("locked");
		String fname = regEntity.getFirstName();
		String lname = regEntity.getLastName();
		String name = fname + lname;
		tempPwd = RandomStringUtil.getAlphaNumericString(6);
		email = regDtls.getEmail();
		String modEmail = email.replaceAll("@gmail.com", "");
		System.out.println(modEmail);
		regEntity.setUsername(modEmail);
		regEntity.setPassword(tempPwd);

		//saveRepo = myService.saveAccount(regEntity);
		saveRepo = userEntityRepo.save(regEntity);
		if (saveRepo != null) {
			EmailSender.POSTRequest(email, name, tempPwd);
			attributes.addFlashAttribute(AppConstants.SUCCESS_MSG, msg);
		} else {
			// error msg
			LOGGER.warn(" error  from loadRegForm4 method");
			throw new UserNotFoundException(AppConstants.ERROR_MSG);
		}

		return "redirect:/registerSuccess";

	}

	/**
	 * This method is used to handle the register success and display success
	 * message
	 * 
	 * @param model
	 * @return
	 */
	@RequestMapping(value = "/registerSuccess")
	public String registerSuccess(Model model) {

		RegistrationDtls regDtls = new RegistrationDtls();
		model.addAttribute("register", regDtls);

		return "RegistrationDtls";
	}

	/**
	 * This method is used to display the unlock Account page
	 * 
	 * @param model
	 * @return unlockAccount page
	 */
	@RequestMapping(value = "/unlockAccount")
	public String unlockAccount(Model model) {
		LOGGER.info("Unlock Account page loaded successfully");
		model.addAttribute("email", email);
		RegistrationDtls regDtls = new RegistrationDtls();
		model.addAttribute("register", regDtls);

		return "unlockAccount";
	}

	/**
	 * This method is used to handle post request for unlockAccount page
	 * 
	 * @param regDtls
	 * @param model
	 * @param attributes
	 * @return unlockAccount page
	 */
	@RequestMapping(value = "/passwordRegister", method = RequestMethod.POST)
	public String passwordDtls(@ModelAttribute("register") RegistrationDtls regDtls, Model model,
			RedirectAttributes attributes) {
		LOGGER.info("password Details Saving method called");
		String msg = appProps.getMessages().get(AppConstants.ACCOUNT_SUCCESS);
		String msg2 = appProps.getMessages().get(AppConstants.PASSWORD_CHECK);
		String msg3 = appProps.getMessages().get(AppConstants.TEMPPASSWORD_CHECK);
		String newPwd = regDtls.getNewPwd();
		String confirmPwd = regDtls.getConfirmPwd();
		if (tempPwd.equals(regDtls.getTempPwd())) {
			if (newPwd.equals(confirmPwd)) {
				saveRepo.setPassword(confirmPwd);
				saveRepo.setStatus("unlocked");
				//RegistrationDtlsEntity savedRepo = myService.saveAccount(saveRepo);
				RegistrationDtlsEntity savedRepo = userEntityRepo.save(saveRepo);
				if (savedRepo != null) {
					
					attributes.addFlashAttribute(AppConstants.SUCCESS_MSG, msg);
				} else {
					// exception msg
					LOGGER.warn(" error  from loadRegForm4 method");
					throw new UserNotFoundException(AppConstants.ERROR_MSG);
				}

			} else {
				
				attributes.addFlashAttribute(AppConstants.SUCCESS_MSG, msg2);
			}
		} else {
			
			attributes.addFlashAttribute(AppConstants.SUCCESS_MSG, msg3);
		}

		return "redirect:/verifySuccess";
	}

	/**
	 * This method is used to handle the success message for unlockAccount page
	 * 
	 * @param model
	 * @return UnlockAccount
	 */
	@RequestMapping(value = "/verifySuccess")
	public String verifySuccess(Model model) {
		RegistrationDtls regDtls = new RegistrationDtls();
		model.addAttribute("register", regDtls);
		return "unlockAccount";
	}

}
