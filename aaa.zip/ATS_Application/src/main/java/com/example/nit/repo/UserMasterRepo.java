package com.example.nit.repo;

import java.io.Serializable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.example.nit.entity.RegistrationDtlsEntity;
/**
 * This class is to interact with database
 * @author user
 *
 */

@Repository
public interface UserMasterRepo extends JpaRepository<RegistrationDtlsEntity,Serializable>{
	@Query(value="select id from RegistrationDtlsEntity where username=:username")
	public Integer findNum(String username);
  
}
